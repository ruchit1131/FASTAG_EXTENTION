import random
def OTP():
    return random.randrange(10000,99999)